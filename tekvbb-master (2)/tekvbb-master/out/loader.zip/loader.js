function imageLoader({ src }) {
  return `/images/${src}`;
}

module.exports = imageLoader;
